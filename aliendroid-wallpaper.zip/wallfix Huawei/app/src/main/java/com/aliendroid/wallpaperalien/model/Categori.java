package com.aliendroid.wallpaperalien.model;



public class Categori {

    public int id;
    public String nama_cat;
    public String gambar_cat;

    public Categori() {  }

    public String getNama_cat() {
        return nama_cat;
    }

    public String getGambar_cat() {
        return gambar_cat;
    }

    public Categori(int no, String nm, String gb) {
        this.id=no;
        this.nama_cat = nm ;
        this.gambar_cat = gb;
    }


}
