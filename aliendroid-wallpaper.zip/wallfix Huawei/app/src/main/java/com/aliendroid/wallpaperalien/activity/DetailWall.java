package com.aliendroid.wallpaperalien.activity;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.banner.BannerView;
import com.squareup.picasso.Picasso;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;



import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.Wall2Adapter;
import com.aliendroid.wallpaperalien.adapter.SharedPreference;
import com.aliendroid.wallpaperalien.model.WallList;

public class DetailWall extends AppCompatActivity {
    /*
Iklan Banner
 */
    private BannerView defaultBannerView;
    private static final int REFRESH_TIME = 30;

    private final String TAG = "abc";
    private Button button;
    private Button bshare, sethome, setlock;
    public ImageView avatar_url;
    private int position = 0;
    int i=0;
    SharedPreference sharedPreference;
    private FloatingActionButton bfloat;
    private ImageView kembali;
    private LinearLayout menuFl;

    private ImageView bnext, bprev, bdown;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle saveInsBundleState) {
        super.onCreate(saveInsBundleState);
        setContentView(R.layout.activity_detail_wall);

              /*
        Implementasi banner
         */
        defaultBannerView = findViewById(R.id.hw_banner_view);
        defaultBannerView.setBannerRefresh(REFRESH_TIME);
        AdParam adParam = new AdParam.Builder().build();
        defaultBannerView.loadAd(adParam);

        bfloat = (FloatingActionButton) findViewById(R.id.bfloat);
        sharedPreference = new SharedPreference();
        menuFl = findViewById(R.id.menuFl);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        button = (Button) findViewById(R.id.imageView4);
        bshare = (Button) findViewById(R.id.setlockhome);
        kembali = (ImageView) findViewById(R.id.imageView2);
        sethome=findViewById(R.id.imagesethome);
        setlock=findViewById(R.id.imagesetlock);

        if (ContextCompat.checkSelfPermission(DetailWall.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //Permission was denied
            //Request for permission
            ActivityCompat.requestPermissions(DetailWall.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    123);
        }

        if (ContextCompat.checkSelfPermission(DetailWall.this, Manifest.permission.SET_WALLPAPER)
                != PackageManager.PERMISSION_GRANTED) {
            //Permission was denied
            //Request for permission
            ActivityCompat.requestPermissions(DetailWall.this,
                    new String[]{Manifest.permission.SET_WALLPAPER},
                    124);
        }

        setSupportActionBar(toolbar);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            position = extras.getInt("position");
        } else {
            if (saveInsBundleState != null) {
                position = saveInsBundleState.getInt("position");
            } else {
                position = 1;
            }
        }

        bfloat.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (i==0){
                    menuFl.setVisibility(View.VISIBLE);

                    i++;
                } else {
                    menuFl.setVisibility(View.GONE);

                    i=0;
                }
            }
        });


        kembali.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                finish();
            }
        });

        /*If a product exists in shared preferences then set heart_red drawable
         * and set a tag*/
        if (checkFavoriteItem(Wall2Adapter.mFilteredList.get(position))) {
            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
            button.setTag("red");

        } else {

            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));
            button.setTag("gray");
        }


        TextView textView = (TextView)toolbar.findViewById(R.id.toolbarTextView);
        textView.setText(Wall2Adapter.mFilteredList.get(position).getHtml_url());

        //sharedPreference.addFavorite(products.add(pos));

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        avatar_url = (ImageView) findViewById(R.id.imageView3);
       //webView = (WebView) findViewById(R.id.web_view);
        Picasso.get()
                .load(Wall2Adapter.mFilteredList.get(position).getAvatar_url())
                .into(avatar_url);

        String mimeType = "text/html";
        String encoding = "utf-8";
       // htmlData = Wall2Adapter.mFilteredList.get(position).getDec();
        // Load html source code into webview to show the html content.
        //webView.loadDataWithBaseURL(null, htmlData, mimeType, encoding, null);
        bnext = findViewById(R.id.bnext);
        bprev = findViewById(R.id.bprev);
        bdown = findViewById(R.id.bdown);
        bprev.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                position--;
                position = (position +Wall2Adapter.mFilteredList.size()) % Wall2Adapter.mFilteredList.size();

                Picasso.get()
                        .load(Wall2Adapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(Wall2Adapter.mFilteredList.get(position).getHtml_url());

            }
        });



        bnext.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                position++;
                position = position % Wall2Adapter.mFilteredList.size();

                Picasso.get()
                        .load(Wall2Adapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(Wall2Adapter.mFilteredList.get(position).getHtml_url());

            }
        });

        bdown.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Picasso.get()
                        .load(Wall2Adapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                avatar_url.buildDrawingCache();

                Bitmap bmp = avatar_url.getDrawingCache();

                File storageLoc = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES); //context.getExternalFilesDir(null);

                File file = new File(storageLoc, Wall2Adapter.mFilteredList.get(position).getHtml_url() + ".jpg");

                try{
                    FileOutputStream fos = new FileOutputStream(file);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                    fos.close();

                    scanFile(DetailWall.this, Uri.fromFile(file));

                    Toast.makeText(DetailWall.this,
                            "Saved successfully " + Wall2Adapter.mFilteredList.get(position).getHtml_url(), Toast.LENGTH_SHORT)
                            .show();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        setlock.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_LOCK);
                    }
                    Toast.makeText(DetailWall.this, "Wallpaper set Lock Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWall.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }



            }


        });

        bshare.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_LOCK);
                    }
                    Toast.makeText(DetailWall.this, "Wallpaper set Lock Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWall.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWall.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWall.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }



            }


        });

        sethome.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();


                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWall.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWall.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }


            }


        });


        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                String tag = button.getTag().toString();
                if(tag.equalsIgnoreCase("gray"))
                {
                    sharedPreference.addFavorite(DetailWall.this, Wall2Adapter.mFilteredList.get(position));
                    button.setTag("red");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));

                }
                else
                {
                    sharedPreference.removeFavorite(DetailWall.this, Wall2Adapter.mFilteredList.get(position));
                    button.setTag("gray");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));

                }
        }
        });


    }

    private static void scanFile(Context context, Uri imageUri){
        Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        scanIntent.setData(imageUri);
        context.sendBroadcast(scanIntent);

    }


    @Override
    public void onSaveInstanceState(Bundle saveInsBundleState) {
        super.onSaveInstanceState(saveInsBundleState);
        saveInsBundleState.putInt("position", position);

    }

    public boolean checkFavoriteItem(WallList checkProduct) {
        boolean check = false;
        List<WallList> favorites = sharedPreference.getFavorites(this);
        if (favorites != null) {
            for (WallList product : favorites) {
                if (product.equals(checkProduct)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }


    public void onBackPressed(){



        finish();
    }

}
