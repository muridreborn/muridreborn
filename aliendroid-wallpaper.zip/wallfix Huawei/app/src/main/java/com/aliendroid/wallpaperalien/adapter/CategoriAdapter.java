package com.aliendroid.wallpaperalien.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.activity.CategoryActivity;
import com.aliendroid.wallpaperalien.model.Categori;


public class CategoriAdapter extends RecyclerView.Adapter {



    public static ArrayList<Categori> catLists;
    public Context context;
    public static String codecat;
    public static String gbrcat;

    public static ArrayList<Categori> mFilteredList;

    public CategoriAdapter(ArrayList<Categori> catLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.catLists = catLists;
        this.mFilteredList = catLists;
        this.context = context;


    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        // define the View objects

        public TextView nama_cat;
        public ImageView gambar_cat;


        public ViewHolder(View itemView) {
            super(itemView);

            nama_cat = (TextView) itemView.findViewById(R.id.username);
            gambar_cat = (ImageView) itemView.findViewById(R.id.imageView);

        }

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.wall_list, parent, false);
        return new ViewHolder(v);

    }



    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

       if (holder instanceof ViewHolder) {
                    final Categori webList = mFilteredList.get(position);

                    ((ViewHolder)holder).nama_cat.setText(webList.getNama_cat());
                    Picasso.get()
                            .load(webList.getGambar_cat())
                            .into( ((ViewHolder)holder).gambar_cat);

                    ((ViewHolder)holder).gambar_cat.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                       codecat = mFilteredList.get(position).nama_cat;
                        gbrcat = mFilteredList.get(position).getGambar_cat();
                           Intent intent = new Intent(context, CategoryActivity.class);
                          intent.putExtra("position", position);
                           context.startActivity(intent);



                        }
                    });
                }
    }

    @Override
    public int getItemCount() {
        return mFilteredList.size();
    }



    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = catLists;
                } else {

                    ArrayList<Categori> filteredList = new ArrayList<>();

                    for (Categori androidVersion : mFilteredList) {

                        if (androidVersion.getNama_cat().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<Categori>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

}
