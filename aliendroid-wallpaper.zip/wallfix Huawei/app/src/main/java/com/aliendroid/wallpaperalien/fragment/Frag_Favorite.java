package com.aliendroid.wallpaperalien.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.wallpaperalien.adapter.FavAdapter;
import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.SharedPreference;


import static com.aliendroid.wallpaperalien.adapter.FavAdapter.webLists;


public class Frag_Favorite extends Fragment {

    public static final String ARG_ITEM_ID = "favorite_list";
    private RecyclerView recyclerView;
    SharedPreference sharedPreference;
    private FavAdapter adapter;
    Activity activity;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.wall, container, false);
        activity = getActivity();
        sharedPreference = new SharedPreference();
        webLists = sharedPreference.getFavorites(activity);


        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        // recyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(activity, 2);
        recyclerView.setLayoutManager(mLayoutManager);



                adapter = new FavAdapter(webLists, activity);
                recyclerView.setAdapter(adapter);


       // loadUrlData();
        return view;
    }


}