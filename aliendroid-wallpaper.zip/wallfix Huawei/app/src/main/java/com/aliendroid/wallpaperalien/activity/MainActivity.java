package com.aliendroid.wallpaperalien.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.aliendroid.wallpaperalien.BuildConfig;
import com.aliendroid.wallpaperalien.dialogs.AdsConstant;
import com.aliendroid.wallpaperalien.dialogs.ConsentDialog;
import com.aliendroid.wallpaperalien.dialogs.ProtocolDialog;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.fragment.Frag_Categori;
import com.aliendroid.wallpaperalien.fragment.Frag_Favorite;
import com.aliendroid.wallpaperalien.fragment.Frag_MoreApp;
import com.aliendroid.wallpaperalien.fragment.Frag_Wallpaper;
import com.aliendroid.wallpaperalien.adapter.MainFragmentPagerAdapter;
import com.aliendroid.wallpaperalien.R;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.banner.BannerView;
import com.huawei.hms.ads.consent.bean.AdProvider;
import com.huawei.hms.ads.consent.constant.ConsentStatus;
import com.huawei.hms.ads.consent.constant.DebugNeedConsent;
import com.huawei.hms.ads.consent.inter.Consent;
import com.huawei.hms.ads.consent.inter.ConsentUpdateListener;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private static final String TAG = MainActivity.class.getSimpleName();

    /*
   GDPR
    */
    private static final int PROTOCOL_MSG_TYPE = 100;

    private static final int CONSENT_MSG_TYPE = 200;

    private static final int MSG_DELAY_MS = 1000;

    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (MainActivity.this.hasWindowFocus()) {
                switch (msg.what) {
                    case PROTOCOL_MSG_TYPE:
                        showPrivacyDialog();
                        break;
                    case CONSENT_MSG_TYPE:
                        checkConsentStatus();
                        break;
                }
            }
            return false;
        }
    });



    /*
   Iklan Banner
    */
    private BannerView defaultBannerView;
    private static final int REFRESH_TIME = 30;


    ViewPager viewPager;
    MainFragmentPagerAdapter mainFragmentPagerAdapter;
    private CardView iklannative;
    Toolbar toolbar;
    DrawerLayout drawer;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    Fragment fragment = null;
    TabLayout tabLayout;
     RelativeLayout fragma2;
    public static Activity fa;
    private static final int MY_REQUEST_CODE = 17326;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_wall);

        sendMessage(PROTOCOL_MSG_TYPE, MSG_DELAY_MS);

               /*
        Implementasi banner
         */
        defaultBannerView = findViewById(R.id.hw_banner_view);
        defaultBannerView.setBannerRefresh(REFRESH_TIME);
        AdParam adParam = new AdParam.Builder().build();
        defaultBannerView.loadAd(adParam);


        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        fragma2 = findViewById(R.id.fragma2);
        viewPager = findViewById(R.id.viewPager);
       setupViewPager(viewPager);

        // setting tabLayout
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    private void setupViewPager(ViewPager viewPager) {
        mainFragmentPagerAdapter = new MainFragmentPagerAdapter(getSupportFragmentManager());
        mainFragmentPagerAdapter.addFragment(new Frag_Wallpaper(), getString(R.string.recipe));
        mainFragmentPagerAdapter.addFragment(new Frag_Categori(), getString(R.string.categori));
        mainFragmentPagerAdapter.addFragment(new Frag_Favorite(), getString(R.string.fav));
        mainFragmentPagerAdapter.addFragment(new Frag_MoreApp(), getString(R.string.more));
        viewPager.setAdapter(mainFragmentPagerAdapter);

    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        // Untuk memanggil layout dari menu yang dipilih
        if (id == R.id.nav_home) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragma2.setVisibility(View.VISIBLE);
            fragment = new Frag_Wallpaper();
            callFragment(fragment);
        } else if (id == R.id.nav_gallery) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragment = new Frag_Favorite();
            callFragment(fragment);
            fragma2.setVisibility(View.VISIBLE);

        } else if (id == R.id.nav_more) {
        tabLayout.setVisibility(View.GONE);
        viewPager.setVisibility(View.GONE);
        fragment = new Frag_MoreApp();
        callFragment(fragment);
        fragma2.setVisibility(View.VISIBLE);

    } else if (id == R.id.nav_share) {

            String shareLink = "https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID;
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getResources().getString(R.string.shareit)
                            + shareLink);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);

        } else if (id == R.id.nav_beranda) {
            tabLayout.setVisibility(View.VISIBLE);
            viewPager.setVisibility(View.VISIBLE);
            fragma2.setVisibility(View.GONE);
    }else if (id == R.id.nav_cat) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragment = new Frag_Categori();
            callFragment(fragment);
            fragma2.setVisibility(View.VISIBLE);
        }else if (id == R.id.nav_cari) {
            Intent intent=new Intent(getApplicationContext(), CategoryActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_pri) {
        Intent intent=new Intent(getApplicationContext(), PrivacyActivity.class);
        startActivity(intent);
    }


        else if (id == R.id.nav_send) {
            String str = "https://appgallery.huawei.com/#/app/"+ getString(R.string.IDHuawei);
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
        }

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void callFragment(Fragment fragment) {
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_container, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        exitapp();
    }

    private void exitapp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("Exit App");
        builder.setMessage("Are you sure you want to leave the application?");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();

            }
        });

        builder.setNegativeButton("No",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    private void showPrivacyDialog() {
        if (getPreferences(AdsConstant.SP_PROTOCOL_KEY, AdsConstant.DEFAULT_SP_PROTOCOL_VALUE) == 0) {
            Log.i(TAG, "Show protocol dialog.");
            ProtocolDialog dialog = new ProtocolDialog(this);
            dialog.setCallback(new ProtocolDialog.ProtocolDialogCallback() {
                @Override
                public void agree() {
                    sendMessage(CONSENT_MSG_TYPE, MSG_DELAY_MS);
                }

                @Override
                public void cancel() {
                    finish();
                }
            });
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        } else {
            sendMessage(CONSENT_MSG_TYPE, MSG_DELAY_MS);
        }
    }

    private void showConsentDialog(List<AdProvider> adProviders) {
        Log.i(TAG, "Show consent dialog.");
        ConsentDialog dialog = new ConsentDialog(this, adProviders);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private int getPreferences(String key, int defValue) {
        SharedPreferences preferences = getSharedPreferences(AdsConstant.SP_NAME, Context.MODE_PRIVATE);
        int value = preferences.getInt(key, defValue);
        Log.i(TAG, "Key:" + key + ", Preference value is: " + value);
        return value;
    }

    private void sendMessage(int what, int delayMillis) {
        Message msg = Message.obtain();
        msg.what = what;
        mHandler.sendMessageDelayed(msg, delayMillis);
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void checkConsentStatus() {
        final List<AdProvider> adProviderList = new ArrayList<>();
        Consent consentInfo = Consent.getInstance(this);
        consentInfo.addTestDeviceId("********");
        consentInfo.setDebugNeedConsent(DebugNeedConsent.DEBUG_NEED_CONSENT);
        consentInfo.requestConsentUpdate(new ConsentUpdateListener() {
            @Override
            public void onSuccess(ConsentStatus consentStatus, boolean isNeedConsent, List<AdProvider> adProviders) {
                Log.i(TAG, "ConsentStatus: " + consentStatus + ", isNeedConsent: " + isNeedConsent);
                if (isNeedConsent) {
                    if (adProviders != null && adProviders.size() > 0) {
                        adProviderList.addAll(adProviders);
                    }
                    showConsentDialog(adProviderList);
                }
            }

            @Override
            public void onFail(String errorDescription) {
                Log.e(TAG, "User's consent status failed to update: " + errorDescription);
                if (getPreferences(AdsConstant.SP_CONSENT_KEY, AdsConstant.DEFAULT_SP_CONSENT_VALUE) < 0) {
                    // In this example, if the request fails, the consent dialog box is still displayed. In this case, the ad publisher list is empty.
                    showConsentDialog(adProviderList);
                }
            }
        });
    }

}
