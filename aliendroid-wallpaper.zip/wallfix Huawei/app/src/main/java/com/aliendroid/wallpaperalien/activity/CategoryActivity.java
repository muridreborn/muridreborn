package com.aliendroid.wallpaperalien.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.ImageView;

import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.CategoriWallAdapter;
import com.aliendroid.wallpaperalien.model.WallList;

import static com.aliendroid.wallpaperalien.adapter.CategoriAdapter.codecat;
import static com.aliendroid.wallpaperalien.config.Pengaturan.DATA_ON_OFF;
import static com.aliendroid.wallpaperalien.config.Pengaturan.URL_DATA;


public class CategoryActivity extends AppCompatActivity {
    //private static final String URL_DATA = "http://aliendro.id/japaneserecipes.json";
    private RecyclerView recyclerView;
    private CategoriWallAdapter adapter;
    private ArrayList<WallList> webLists;
    private TextView judul;
    private CardView iklannative;
    private ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_wall);

        back = findViewById(R.id.gbcat);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

judul = findViewById(R.id.txtcat);
judul.setText(codecat);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        // recyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(mLayoutManager);

        webLists = new ArrayList<>();

        if (DATA_ON_OFF.equals("1")){
            if (checkConnectivity()){
                loadUrlData();
            } else {
                ambildata();
            }

        } else {
            ambildata();
        }

    }
    private void loadUrlData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Wallpaper");

                    for (int i = 0; i < array.length(); i++){

                        JSONObject jo = array.getJSONObject(i);
                        if(jo.getString("nama_cat").equals(codecat)) {
                            WallList developers = new WallList(jo.getInt("id"), jo.getString("id_wall")
                                    , jo.getString("nama_cat"), jo.getString("judul"),
                                    jo.getString("image"));
                            developers.setViewType(0);
                            webLists.add(developers);
                        }

                    }


                    adapter = new CategoriWallAdapter(webLists, CategoryActivity.this);
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(CategoryActivity.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_cari, menu);

        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(search);
        search(searchView);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }

    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return true;
            }
        });
    }



    public void onBackPressed(){
        finish();
    }

    private boolean checkConnectivity() {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }


    }

    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = this.getAssets().open("wallpaper.json");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void ambildata(){
        try {

            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Wallpaper");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);

                if(jsonData.getString("nama_cat").equals(codecat)) {
                    WallList developers = new WallList(jsonData.getInt("id"), jsonData.getString("id_wall")
                            , jsonData.getString("nama_cat"), jsonData.getString("judul"),
                            jsonData.getString("image"));

                    webLists.add(developers);
                }




            }
            Collections.sort(webLists, new Comparator<WallList>() {
                @Override
                public int compare(WallList o2, WallList o1) {
                    return o1.getId_wal().compareTo(o2.getId_wal());
                }
            });

            adapter = new CategoriWallAdapter(webLists, CategoryActivity.this);
            recyclerView.setAdapter(adapter);

        } catch (JSONException e) {
            Toast.makeText(CategoryActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }
}
