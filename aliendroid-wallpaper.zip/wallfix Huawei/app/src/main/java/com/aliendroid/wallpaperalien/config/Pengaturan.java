package com.aliendroid.wallpaperalien.config;

public class Pengaturan {

    /*
    Pengaturan Iklan online dan offline
     */
    public static String DATA_ON_OFF ="0";

    /*
    JSON data Wallpaper, More App dan Iklan, silahkan uplaod di hosting
    Archire.org dll
     */
    public static final String URL_DATA = "http://hexa.web.id/sample/wallpaper_v2.json";

    public static String Privacy_police="file:///android_asset/privacy_policy.html";

}

