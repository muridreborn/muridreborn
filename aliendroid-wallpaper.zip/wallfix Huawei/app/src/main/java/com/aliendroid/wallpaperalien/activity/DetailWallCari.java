package com.aliendroid.wallpaperalien.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.banner.BannerView;
import com.squareup.picasso.Picasso;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.CategoriWallAdapter;
import com.aliendroid.wallpaperalien.adapter.SharedPreference;
import com.aliendroid.wallpaperalien.model.WallList;

public class DetailWallCari extends AppCompatActivity  {
    /*
Iklan Banner
 */
    private BannerView defaultBannerView;
    private static final int REFRESH_TIME = 30;

    public static String EXTRA_PLAYER = "extra_player";
    public ImageView avatar_url;
    private WebView webView = null;
    private String htmlData = null;
    private int position = 0;
    SharedPreference sharedPreference;
    private Button button;
    private int i=0;
    private Button bshare, sethome, setlock;
    private ImageView kembali;
    private FloatingActionButton bfloat;
    private RelativeLayout iklannative;
    private LinearLayout menuFl;
    private LinearLayout adView2;
    private ImageView bnext, bprev, bdown;

    @Override
    protected void onCreate(Bundle saveInsBundleState) {
        super.onCreate(saveInsBundleState);
        setContentView(R.layout.activity_detail_wall);

              /*
        Implementasi banner
         */
        defaultBannerView = findViewById(R.id.hw_banner_view);
        defaultBannerView.setBannerRefresh(REFRESH_TIME);
        AdParam adParam = new AdParam.Builder().build();
        defaultBannerView.loadAd(adParam);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            position = extras.getInt("position");
        } else {
            if (saveInsBundleState != null) {
                position = saveInsBundleState.getInt("position");
            } else {
                position = 1;
            }
        }

        bfloat = (FloatingActionButton) findViewById(R.id.bfloat);
        sethome=findViewById(R.id.imagesethome);
        setlock=findViewById(R.id.imagesetlock);
        button = (Button) findViewById(R.id.imageView4);
        bshare = (Button) findViewById(R.id.setlockhome);
        kembali = (ImageView) findViewById(R.id.imageView2);
        menuFl = findViewById(R.id.menuFl);
        bfloat.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (i==0){
                    menuFl.setVisibility(View.VISIBLE);

                    i++;
                } else {
                    menuFl.setVisibility(View.GONE);

                    i=0;
                }
            }
        });


        if (ContextCompat.checkSelfPermission(DetailWallCari.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //Permission was denied
            //Request for permission
            ActivityCompat.requestPermissions(DetailWallCari.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    123);
        }

        kembali.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {



                finish();

            }
        });

        sharedPreference = new SharedPreference();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        TextView textView = (TextView)toolbar.findViewById(R.id.toolbarTextView);
        textView.setText(CategoriWallAdapter.mFilteredList.get(position).getHtml_url());
        if (checkFavoriteItem(CategoriWallAdapter.mFilteredList.get(position))) {
            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
            button.setTag("red");

        } else {

            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));
            button.setTag("gray");
        }

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        avatar_url = (ImageView) findViewById(R.id.imageView3);
       // webView = (WebView) findViewById(R.id.web_view);
        Picasso.get()
                .load(CategoriWallAdapter.mFilteredList.get(position).getAvatar_url())
                .into(avatar_url);

        String mimeType = "text/html";
        String encoding = "utf-8";
        // Load html source code into webview to show the html content.
       // webView.loadDataWithBaseURL(null, htmlData, mimeType, encoding, null);



        bnext = findViewById(R.id.bnext);
        bprev = findViewById(R.id.bprev);
        bdown = findViewById(R.id.bdown);
        bprev.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                position--;


                position = (position + CategoriWallAdapter.mFilteredList.size()) % CategoriWallAdapter.mFilteredList.size();

                Picasso.get()
                        .load(CategoriWallAdapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(CategoriWallAdapter.mFilteredList.get(position).getHtml_url());

            }
        });

        bdown.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Picasso.get()
                        .load(CategoriWallAdapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                avatar_url.buildDrawingCache();

                Bitmap bmp = avatar_url.getDrawingCache();

                File storageLoc = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES); //context.getExternalFilesDir(null);

                File file = new File(storageLoc, CategoriWallAdapter.mFilteredList.get(position).getHtml_url() + ".jpg");

                try{
                    FileOutputStream fos = new FileOutputStream(file);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                    fos.close();

                    scanFile(DetailWallCari.this, Uri.fromFile(file));

                    Toast.makeText(DetailWallCari.this,
                            "Saved successfully " + CategoriWallAdapter.mFilteredList.get(position).getHtml_url(), Toast.LENGTH_SHORT)
                            .show();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


        bnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                position++;
                position = position % CategoriWallAdapter.mFilteredList.size();

                Picasso.get()
                        .load(CategoriWallAdapter.mFilteredList.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(CategoriWallAdapter.mFilteredList.get(position).getHtml_url());

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String tag = button.getTag().toString();
                if(tag.equalsIgnoreCase("gray"))
                {
                    sharedPreference.addFavorite(DetailWallCari.this, CategoriWallAdapter.mFilteredList.get(position));
                    button.setTag("red");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));

                }
                else
                {
                    sharedPreference.removeFavorite(DetailWallCari.this, CategoriWallAdapter.mFilteredList.get(position));
                    button.setTag("gray");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));

                }
            }
        });

        setlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_LOCK);
                    }
                    Toast.makeText(DetailWallCari.this, "Wallpaper set Lock Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallCari.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });


        bshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_LOCK);
                    }
                    Toast.makeText(DetailWallCari.this, "Wallpaper set Lock Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallCari.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWallCari.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallCari.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });

        sethome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();
                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWallCari.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallCari.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle saveInsBundleState) {
        super.onSaveInstanceState(saveInsBundleState);
        saveInsBundleState.putInt("position", position);

    }

    public boolean checkFavoriteItem(WallList checkProduct) {
        boolean check = false;
        List<WallList> favorites = sharedPreference.getFavorites(this);
        if (favorites != null) {
            for (WallList product : favorites) {
                if (product.equals(checkProduct)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }
    public void onBackPressed(){


        finish();
    }
    private static void scanFile(Context context, Uri imageUri){
        Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        scanIntent.setData(imageUri);
        context.sendBroadcast(scanIntent);

    }

}
