package com.aliendroid.wallpaperalien.model;

/**
 * Created by EKENE on 7/23/2017.
 */

public class WallList {

    private int login;
    private String id_wal;
    private String nama_cat;
    private String avatar_url;
    private String html_url;

    private int viewType;

    public WallList() {

    }


    public Integer getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public int getLogin() {
        return login;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public String getId_wal() {
        return id_wal;
    }

    public String getNama_cat() {
        return nama_cat;
    }



    public String getHtml_url() {
        return html_url;
    }



    public WallList(int id,String ic, String nc, String jdl, String img) {
        this.login = id;
        this.id_wal=ic;
        this.nama_cat=nc;
        this.html_url = jdl;
        this.avatar_url = img;


    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + login;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        WallList other = (WallList) obj;
        if (login != other.login)
            return false;
        return true;
    }


}
