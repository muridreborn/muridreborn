package com.aliendroid.wallpaperalien.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.wallpaperalien.config.Pengaturan;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.mopub.mobileads.MoPubInterstitial;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;


import java.util.List;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.activity.DetailWallFav;
import com.aliendroid.wallpaperalien.model.WallList;
import com.unity3d.ads.UnityAds;


import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninter;
import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninterFan;
import static com.aliendroid.wallpaperalien.config.Pengaturan.INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.interval;
import static com.aliendroid.wallpaperalien.activity.SplahsActivity.counter;



public class FavAdapter extends RecyclerView.Adapter {
    SharedPreference sharedPreference;
    private InterstitialAd mInterstitialAd;
    private final int VIEW_ITEM = 1;
    public static List <WallList> webLists;
    private Context context;
    private MoPubInterstitial mInterstitial;
    public FavAdapter(List<WallList> webLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.webLists = webLists;
        this.context = context;
        sharedPreference = new SharedPreference();

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        // define the View objects

        public TextView html_url;
        public ImageView avatar_url;
        public RelativeLayout linearLayout;
        public Button favoriteImg;

        public ViewHolder(View itemView) {
            super(itemView);

            mInterstitialAd = new InterstitialAd(context);
            mInterstitialAd.setAdUnitId(INTER);
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitial = new MoPubInterstitial((Activity) context, Pengaturan.INTER_MOPUB);
            mInterstitial.load();
            html_url = (TextView) itemView.findViewById(R.id.username);
            avatar_url = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (RelativeLayout) itemView.findViewById(R.id.linearLayout);
            favoriteImg = (Button) itemView.findViewById(R.id.imageView5);
        }

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.wall_list_fav, parent, false);
            return new ViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_progressbar, parent, false);
            return new ProgressViewHolder(v);
        }




    }
    private static class ProgressViewHolder extends RecyclerView.ViewHolder {
        private static ProgressBar progressBar;

        private ProgressViewHolder(View v) {
            super(v);
            progressBar = v.findViewById(R.id.progressBar);
        }
    }



    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder,  final int position) {

        // this method will bind the data to the ViewHolder from whence it'll be shown to other Views
        if (holder instanceof ViewHolder) {
            final WallList webList = webLists.get(position);



            ((ViewHolder)holder).html_url.setText(webList.getHtml_url());

            Picasso.get()
                    .load(webList.getAvatar_url())
                    .into( ((ViewHolder)holder).avatar_url);

            ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    Intent intent = new Intent(context, DetailWallFav.class);
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                    //((MainActivity)context).finish();
                    if (counter>=interval){
                        if (PENGATURAN_IKLAN.equals("1")){
                            iklaninter();
                        } else if (PENGATURAN_IKLAN.equals("2")){
                            iklaninterFan();
                        }else if (PENGATURAN_IKLAN.equals("3")){
                            StartAppAd.showAd(context);
                        }else if (PENGATURAN_IKLAN.equals("4")){
                            if (UnityAds.isReady (Unity_INTER)) {
                                UnityAds.show ((Activity) context,Unity_INTER);
                            }
                        }else if (PENGATURAN_IKLAN.equals("5")){
                            if (mInterstitial.isReady()) {
                                mInterstitial.show();
                                mInterstitial.load();
                            } else {
                                mInterstitial.load();
                            }
                        }
                        counter=0;
                    } else {
                        counter++;
                    }

                }
            });


            ((ViewHolder)holder).favoriteImg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    String tag =  ((ViewHolder)holder).favoriteImg.getTag().toString();
                    if(tag.equalsIgnoreCase("gray"))
                    {
                        sharedPreference.addFavorite(context, Wall2Adapter.webLists.get(position));
                        ((ViewHolder)holder).favoriteImg.setTag("red");
                        ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
                    }
                    else
                    {
                        sharedPreference.removeFavorite(context, Wall2Adapter.webLists.get(position));
                        ((ViewHolder)holder).favoriteImg.setTag("gray");
                        ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));

                    }

                }
            });


            if (checkFavoriteItem(webLists.get(position))) {
                ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
                ((ViewHolder)holder).favoriteImg.setTag("red");

            } else {

                ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));
                ((ViewHolder)holder).favoriteImg.setTag("gray");
            }


        }


    }

    @Override

    //return the size of the listItems (developersList)

    public int getItemCount() {

        return null!=webLists?webLists.size():0;

    }

    @Override
    public int getItemViewType(int position) {

        return VIEW_ITEM;
    }

    /*Checks whether a particular product exists in SharedPreferences*/
    public boolean checkFavoriteItem(WallList checkProduct) {
        boolean check = false;
        List<WallList> favorites = sharedPreference.getFavorites(context);
        if (favorites != null) {
            for (WallList product : favorites) {
                if (product.equals(checkProduct)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }

}
