package com.aliendroid.wallpaperalien.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.CategoriWallAdapter;
import com.aliendroid.wallpaperalien.model.WallList;
import com.mopub.mobileads.MoPubView;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;


import static com.aliendroid.wallpaperalien.adapter.CategoriAdapter.codecat;
import static com.aliendroid.wallpaperalien.config.Pengaturan.BANNER_MOPUB;
import static com.aliendroid.wallpaperalien.config.Pengaturan.DATA_ON_OFF;
import static com.aliendroid.wallpaperalien.config.Pengaturan.FAN_BANNER_NATIVE;
import static com.aliendroid.wallpaperalien.config.Pengaturan.NATIV;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.URL_DATA;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_BANNER;


public class CategoryActivity extends AppCompatActivity implements NativeAdListener {
    //private static final String URL_DATA = "http://aliendro.id/japaneserecipes.json";
    private RecyclerView recyclerView;
    private CategoriWallAdapter adapter;
    private ArrayList<WallList> webLists;
    private TextView judul;
    private CardView iklannative;
    private ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_wall);

        iklannative = (CardView) findViewById(R.id.iklannative) ;
        back = findViewById(R.id.gbcat);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        judul = findViewById(R.id.txtcat);
        judul.setText(codecat);

        RelativeLayout starappiklan=findViewById(R.id.mainLayout);
        if (PENGATURAN_IKLAN.equals("1")){
            iklannativeadmob();
            starappiklan.setVisibility(View.GONE);

        } else if (PENGATURAN_IKLAN.equals("2")){
            nativbanner();
            starappiklan.setVisibility(View.GONE);
        } else if (PENGATURAN_IKLAN.equals("3")){
            starappiklan.setVisibility(View.VISIBLE);
        } else if (PENGATURAN_IKLAN.equals("4")){
            bannerunity();
            starappiklan.setVisibility(View.GONE);
        }else if (PENGATURAN_IKLAN.equals("5")){
            bannermopub();
            starappiklan.setVisibility(View.GONE);

        }




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);


        setSupportActionBar(toolbar);




        getSupportActionBar().setDisplayShowTitleEnabled(false);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        // recyclerView.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(mLayoutManager);

        webLists = new ArrayList<>();

        if (DATA_ON_OFF.equals("1")){
            if (checkConnectivity()){
                loadUrlData();
            } else {
                ambildata();
            }

        } else {
            ambildata();
        }



    }
    private void loadUrlData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Wallpaper");

                    for (int i = 0; i < array.length(); i++){

                        JSONObject jo = array.getJSONObject(i);
                        if(jo.getString("nama_cat").equals(codecat)) {
                            WallList developers = new WallList(jo.getInt("id"), jo.getString("id_wall")
                                    , jo.getString("nama_cat"), jo.getString("judul"),
                                    jo.getString("image"));
                            developers.setViewType(0);
                            webLists.add(developers);
                        }

                    }


                    adapter = new CategoriWallAdapter(webLists, CategoryActivity.this);
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(CategoryActivity.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_cari, menu);

        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(search);
        search(searchView);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }

    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapter.getFilter().filter(newText);
                return true;
            }
        });
    }



    public void onBackPressed(){
        finish();
    }

    private void iklannativeadmob() {
        AdLoader adLoader = new AdLoader.Builder(this,NATIV)
                .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        NativeTemplateStyle styles = new
                                NativeTemplateStyle.Builder().build();

                        TemplateView template = findViewById(R.id.my_template);
                        template.setStyles(styles);
                        template.setNativeAd(unifiedNativeAd);

                    }



                })

                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        iklannative.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLoaded() {
                        iklannative.setVisibility(View.VISIBLE);
                    }

                })
                .withNativeAdOptions(new NativeAdOptions.Builder()
                        // Methods in the NativeAdOptions.Builder class can be
                        // used here to specify individual options settings.
                        .build())
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());

    }

    /*
   native FAN
    */
    private LinearLayout mAdView;
    private FrameLayout mAdChoicesContainer;
    private NativeAdLayout mNativeBannerAdContainer;
    private @Nullable
    NativeBannerAd mNativeBannerAd;
    private boolean isAdViewAdded;

    public void nativbanner(){
        LayoutInflater inflater = LayoutInflater.from(CategoryActivity.this);
        mNativeBannerAdContainer = findViewById(R.id.native_banner_ad_container);
        mAdView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_unit, mNativeBannerAdContainer, false);
        mAdChoicesContainer = mAdView.findViewById(R.id.ad_choices_container);
        mNativeBannerAd = new NativeBannerAd(CategoryActivity.this, FAN_BANNER_NATIVE);
        inflateAd(mNativeBannerAd, mAdView);
        mNativeBannerAd.loadAd( mNativeBannerAd
                .buildLoadAdConfig()
                .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
                .withAdListener(CategoryActivity.this)
                .build());

    }


    private void inflateAd (NativeBannerAd nativeBannerAd, View adView) {
        // Create native UI using the ad metadata.
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Setting the Text
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());

        // You can use the following to specify the clickable areas.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdCallToAction);

        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        ImageView nativeImageViewAdIconView = adView.findViewById(R.id.image_view_icon_view);

        nativeAdIconView.setVisibility(View.VISIBLE);
        nativeImageViewAdIconView.setVisibility(View.GONE);
        nativeBannerAd.registerViewForInteraction(
                mNativeBannerAdContainer, nativeAdIconView, clickableViews);
        sponsoredLabel.setText(R.string.sponsored);
    }

    @Override
    public void onError(Ad ad, AdError adError) {

    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (mNativeBannerAd == null || mNativeBannerAd != ad) {
            // Race condition, load() called again before last ad was displayed
            return;
        }
        if (!isAdViewAdded) {
            isAdViewAdded = true;
            mNativeBannerAdContainer.addView(mAdView);
        }
        // Unregister last ad
        mNativeBannerAd.unregisterView();

        if (!mNativeBannerAd.isAdLoaded() || mNativeBannerAd.isAdInvalidated()) {
            return;
        }
        AdOptionsView adOptionsView =
                new AdOptionsView(
                        this,
                        mNativeBannerAd,
                        mNativeBannerAdContainer,
                        AdOptionsView.Orientation.HORIZONTAL,
                        20);
        mAdChoicesContainer.removeAllViews();
        mAdChoicesContainer.addView(adOptionsView);

        inflateAd(mNativeBannerAd, mAdView);

    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    @Override
    public void onMediaDownloaded(Ad ad) {

    }


    private boolean checkConnectivity() {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }


    }

    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = this.getAssets().open("wallpaper.json");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void ambildata(){
        try {

            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Wallpaper");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);

                if(jsonData.getString("nama_cat").equals(codecat)) {
                    WallList developers = new WallList(jsonData.getInt("id"), jsonData.getString("id_wall")
                            , jsonData.getString("nama_cat"), jsonData.getString("judul"),
                            jsonData.getString("image"));

                    webLists.add(developers);
                }




            }
            Collections.sort(webLists, new Comparator<WallList>() {
                @Override
                public int compare(WallList o2, WallList o1) {
                    return o1.getId_wal().compareTo(o2.getId_wal());
                }
            });

            adapter = new CategoriWallAdapter(webLists, CategoryActivity.this);
            recyclerView.setAdapter(adapter);

        } catch (JSONException e) {
            Toast.makeText(CategoryActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private MoPubView moPubView;
    public void bannermopub() {
        moPubView = (MoPubView) findViewById(R.id.adview);
        moPubView.setAdUnitId(BANNER_MOPUB);
        moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
    }

    BannerView bottomBanner;
    RelativeLayout bottomBannerView;
    public  void bannerunity(){
        bottomBanner = new BannerView(CategoryActivity.this, Unity_BANNER, new UnityBannerSize(320, 50));
        //bottomBanner.setListener(bannerListener);
        bottomBannerView = findViewById(R.id.bottomBanner);
        bottomBannerView.addView(bottomBanner);
        bottomBanner.load();
    }
}
