package com.aliendroid.wallpaperalien.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.mopub.mobileads.MoPubView;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.BuildConfig;
import com.aliendroid.wallpaperalien.fragment.Frag_Categori;
import com.aliendroid.wallpaperalien.fragment.Frag_Favorite;
import com.aliendroid.wallpaperalien.fragment.Frag_MoreApp;
import com.aliendroid.wallpaperalien.fragment.Frag_Wallpaper;
import com.aliendroid.wallpaperalien.adapter.MainFragmentPagerAdapter;
import com.aliendroid.wallpaperalien.R;
import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;


import static com.aliendroid.wallpaperalien.config.Pengaturan.BANNER_MOPUB;
import static com.aliendroid.wallpaperalien.config.Pengaturan.TESTMODE_UNITY_ADS;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_BANNER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.unityGameID;
import static com.google.android.play.core.install.model.ActivityResult.RESULT_IN_APP_UPDATE_FAILED;
import static com.google.android.play.core.install.model.AppUpdateType.FLEXIBLE;
import static com.aliendroid.wallpaperalien.config.Pengaturan.FAN_BANNER_NATIVE;
import static com.aliendroid.wallpaperalien.config.Pengaturan.LINK;
import static com.aliendroid.wallpaperalien.config.Pengaturan.NATIV;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.STARAPPID;
import static com.aliendroid.wallpaperalien.config.Pengaturan.STATUS;



public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,
        NativeAdListener, IUnityAdsListener {
    ViewPager viewPager;
    MainFragmentPagerAdapter mainFragmentPagerAdapter;
    private CardView iklannative;
    Toolbar toolbar;
    DrawerLayout drawer;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    Fragment fragment = null;
    TabLayout tabLayout;
     RelativeLayout fragma2;
    public static Activity fa;
    private ConsentInformation consentInformation;
    private ConsentForm consentForm;

    private static final int MY_REQUEST_CODE = 17326;

    ReviewInfo reviewInfo;
    ReviewManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_wall);
        toolbar = findViewById(R.id.toolbar);
        notif();
        Review();

        final UnityAdsListener myAdsListener = new UnityAdsListener();
        // Initialize the SDK:
        UnityAds.initialize (this, unityGameID, myAdsListener, TESTMODE_UNITY_ADS);


        setSupportActionBar(toolbar);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();

        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
                    @Override
                    public void onConsentInfoUpdateSuccess() {
                        if (consentInformation.isConsentFormAvailable()) {
                            loadForm();
                        }
                    }
                },
                new ConsentInformation.OnConsentInfoUpdateFailureListener() {
                    @Override
                    public void onConsentInfoUpdateFailure(FormError formError) {
                        // Handle the error.
                    }
                });
        iklannative = (CardView) findViewById(R.id.iklannative) ;

        RelativeLayout starappiklan=findViewById(R.id.mainLayout);
        if (PENGATURAN_IKLAN.equals("1")){
            iklannativeadmob();
            starappiklan.setVisibility(View.GONE);


        } else if (PENGATURAN_IKLAN.equals("2")){
            nativbanner();
            starappiklan.setVisibility(View.GONE);

        } else if (PENGATURAN_IKLAN.equals("3")){
            starappiklan.setVisibility(View.VISIBLE);
        } else if (PENGATURAN_IKLAN.equals("4")){
            bannerunity();
        } else if (PENGATURAN_IKLAN.equals("5")){
            bannermopub();
            starappiklan.setVisibility(View.GONE);

        }

        {
            fa = this;
        }
        fragma2 = findViewById(R.id.fragma2);
        viewPager = findViewById(R.id.viewPager);
       setupViewPager(viewPager);

        // setting tabLayout
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        if (STATUS.equals("1")) {
            String str = LINK;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
        }

        if (PENGATURAN_IKLAN.equals("3")){
            StartAppSDK.init(this, STARAPPID, true);
            StartAppAd.disableSplash();

        }

    }

    private void setupViewPager(ViewPager viewPager) {
        mainFragmentPagerAdapter = new MainFragmentPagerAdapter(getSupportFragmentManager());
        mainFragmentPagerAdapter.addFragment(new Frag_Wallpaper(), getString(R.string.recipe));
        mainFragmentPagerAdapter.addFragment(new Frag_Categori(), getString(R.string.categori));
        mainFragmentPagerAdapter.addFragment(new Frag_Favorite(), getString(R.string.fav));
        mainFragmentPagerAdapter.addFragment(new Frag_MoreApp(), getString(R.string.more));
        viewPager.setAdapter(mainFragmentPagerAdapter);


    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        // Untuk memanggil layout dari menu yang dipilih
        if (id == R.id.nav_home) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragma2.setVisibility(View.VISIBLE);
            fragment = new Frag_Wallpaper();
            callFragment(fragment);
        } else if (id == R.id.nav_gallery) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragment = new Frag_Favorite();
            callFragment(fragment);
            fragma2.setVisibility(View.VISIBLE);

        } else if (id == R.id.nav_more) {
        tabLayout.setVisibility(View.GONE);
        viewPager.setVisibility(View.GONE);
        fragment = new Frag_MoreApp();
        callFragment(fragment);
        fragma2.setVisibility(View.VISIBLE);

    }else if (id == R.id.nav_update) {
            //cekversi();
          checkUpdate();

        }
        else if (id == R.id.nav_share) {

            String shareLink = "https://play.google.com/store/apps/details?id="
                    + BuildConfig.APPLICATION_ID;
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getResources().getString(R.string.shareit)
                            + shareLink);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);

        } else if (id == R.id.nav_beranda) {
            tabLayout.setVisibility(View.VISIBLE);
            viewPager.setVisibility(View.VISIBLE);
            fragma2.setVisibility(View.GONE);
    }else if (id == R.id.nav_cat) {
            tabLayout.setVisibility(View.GONE);
            viewPager.setVisibility(View.GONE);
            fragment = new Frag_Categori();
            callFragment(fragment);
            fragma2.setVisibility(View.VISIBLE);
        }else if (id == R.id.nav_cari) {
            Intent intent=new Intent(getApplicationContext(), CategoryActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_pri) {
        Intent intent=new Intent(getApplicationContext(), PrivacyActivity.class);
        startActivity(intent);
    }


        else if (id == R.id.nav_send) {
            String str = "https://play.google.com/store/apps/details?id="+ BuildConfig.APPLICATION_ID;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
        }

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void callFragment(Fragment fragment) {
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_container, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        exitapp();
    }

    private void iklannativeadmob() {
        AdLoader adLoader = new AdLoader.Builder(this,NATIV)
                .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        NativeTemplateStyle styles = new
                                NativeTemplateStyle.Builder().build();

                        TemplateView template = findViewById(R.id.my_template);
                        template.setStyles(styles);
                        template.setNativeAd(unifiedNativeAd);

                    }



                })

                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        iklannative.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLoaded() {
                        iklannative.setVisibility(View.VISIBLE);
                    }

                })
                .withNativeAdOptions(new NativeAdOptions.Builder()
                        // Methods in the NativeAdOptions.Builder class can be
                        // used here to specify individual options settings.
                        .build())
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());

    }

    private void exitapp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("Exit App");
        builder.setMessage("Are you sure you want to leave the application?");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();

            }
        });

        builder.setNegativeButton("No",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    public void loadForm() {
        UserMessagingPlatform.loadConsentForm(
                this,
                new UserMessagingPlatform.OnConsentFormLoadSuccessListener() {
                    @Override
                    public void onConsentFormLoadSuccess(ConsentForm consentForm) {
                        MainActivity.this.consentForm = consentForm;
                    }
                },
                new UserMessagingPlatform.OnConsentFormLoadFailureListener() {
                    @Override
                    public void onConsentFormLoadFailure(FormError formError) {
                        // Handle the error
                    }
                }
        );
    }

    public static final String USE_IMAGE_VIEW = "useImageView";
    private static final String TAG =MainActivity.class.getSimpleName();


    /*
    native FAN
     */
    private LinearLayout mAdView;
    private FrameLayout mAdChoicesContainer;
    private NativeAdLayout mNativeBannerAdContainer;
    private @Nullable NativeBannerAd mNativeBannerAd;
    private boolean isAdViewAdded;

    public void nativbanner(){
        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        mNativeBannerAdContainer = findViewById(R.id.native_banner_ad_container);
        mAdView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_unit, mNativeBannerAdContainer, false);
        mAdChoicesContainer = mAdView.findViewById(R.id.ad_choices_container);
        mNativeBannerAd = new NativeBannerAd(MainActivity.this, FAN_BANNER_NATIVE);
        inflateAd(mNativeBannerAd, mAdView);
        mNativeBannerAd.loadAd( mNativeBannerAd
                .buildLoadAdConfig()
                .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
                .withAdListener(MainActivity.this)
                .build());

    }


    private void inflateAd (NativeBannerAd nativeBannerAd, View adView) {
        // Create native UI using the ad metadata.
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Setting the Text
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());

        // You can use the following to specify the clickable areas.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdCallToAction);

        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        ImageView nativeImageViewAdIconView = adView.findViewById(R.id.image_view_icon_view);

            nativeAdIconView.setVisibility(View.VISIBLE);
            nativeImageViewAdIconView.setVisibility(View.GONE);
            nativeBannerAd.registerViewForInteraction(
                    mNativeBannerAdContainer, nativeAdIconView, clickableViews);
        sponsoredLabel.setText(R.string.sponsored);
    }

    @Override
    public void onError(Ad ad, AdError adError) {

    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (mNativeBannerAd == null || mNativeBannerAd != ad) {
            // Race condition, load() called again before last ad was displayed
            return;
        }
        if (!isAdViewAdded) {
            isAdViewAdded = true;
            mNativeBannerAdContainer.addView(mAdView);
        }
        // Unregister last ad
        mNativeBannerAd.unregisterView();

        if (!mNativeBannerAd.isAdLoaded() || mNativeBannerAd.isAdInvalidated()) {
            return;
        }
        AdOptionsView adOptionsView =
                new AdOptionsView(
                        this,
                        mNativeBannerAd,
                        mNativeBannerAdContainer,
                        AdOptionsView.Orientation.HORIZONTAL,
                        20);
        mAdChoicesContainer.removeAllViews();
        mAdChoicesContainer.addView(adOptionsView);

        inflateAd(mNativeBannerAd, mAdView);

    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    @Override
    public void onMediaDownloaded(Ad ad) {

    }

    /*
    In App Update
     */
    AppUpdateManager appUpdateManager;
    com.google.android.play.core.tasks.Task<AppUpdateInfo> appUpdateInfoTask;

   private void checkUpdate(){
        appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.registerListener(listener);

        appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateInfoTask.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @SuppressLint("WrongConstant")
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                Log.d("appUpdateInfo :", "packageName :"+appUpdateInfo.packageName()+ ", "+ "availableVersionCode :"+ appUpdateInfo.availableVersionCode() +", "+"updateAvailability :"+ appUpdateInfo.updateAvailability() +", "+ "installStatus :" + appUpdateInfo.installStatus() );

                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(FLEXIBLE)){
                    requestUpdate(appUpdateInfo);
                    Log.d("UpdateAvailable","update is there ");
                }
                else if (appUpdateInfo.updateAvailability() == 3){
                    Log.d("Update","3");
                    notifyUser();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "No Update Available", Toast.LENGTH_SHORT).show();
                    Log.d("NoUpdateAvailable","update is not there ");
                }
            }
        });
    }
    private void requestUpdate(AppUpdateInfo appUpdateInfo){
        try {
            appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.FLEXIBLE, MainActivity.this,MY_REQUEST_CODE);
            resume();
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == MY_REQUEST_CODE){
            switch (resultCode){
                case Activity.RESULT_OK:
                    if(resultCode != RESULT_OK){
                        Toast.makeText(this,"RESULT_OK" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_OK  :",""+resultCode);
                    }
                    break;
                case Activity.RESULT_CANCELED:

                    if (resultCode != RESULT_CANCELED){
                        Toast.makeText(this,"RESULT_CANCELED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_CANCELED  :",""+resultCode);
                    }
                    break;
                case RESULT_IN_APP_UPDATE_FAILED:

                    if (resultCode != RESULT_IN_APP_UPDATE_FAILED){

                        Toast.makeText(this,"RESULT_IN_APP_UPDATE_FAILED" +resultCode, Toast.LENGTH_LONG).show();
                        Log.d("RESULT_IN_APP_FAILED:",""+resultCode);
                    }
            }
        }
    }

    InstallStateUpdatedListener listener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(InstallState installState) {
            if (installState.installStatus() == InstallStatus.DOWNLOADED){
                Log.d("InstallDownloded","InstallStatus sucsses");
                notifyUser();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        appUpdateManager.unregisterListener((InstallStateUpdatedListener) this);
    }

    private void notifyUser() {

        Snackbar snackbar =
                Snackbar.make(findViewById(R.id.drawer_layout),
                        "An update has just been downloaded.",
                        Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                appUpdateManager.completeUpdate();
            }
        });
        snackbar.setActionTextColor(
                getResources().getColor(R.color.browser_actions_bg_grey));
        snackbar.show();
    }

    private void resume(){
        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED){
                    notifyUser();

                }

            }
        });
    }

    /*
    In app review
     */

    private void Review(){
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            @Override
            public void onComplete(@NonNull Task<ReviewInfo> task) {
                if(task.isSuccessful()){
                    reviewInfo = task.getResult();
                    manager.launchReviewFlow(MainActivity.this, reviewInfo).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(Exception e) {
                            //Toast.makeText(MainActivity.this, "Rating Failed", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                           // Toast.makeText(MainActivity.this, "Review Completed, Thank You!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                Toast.makeText(MainActivity.this, "In-App Request Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
    Firebase GCM
     */
    void notif(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId  = getString(R.string.default_notification_channel_id);
            String channelName = getString(R.string.default_notification_channel_name);
            NotificationManager notificationManager =
                    getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(new NotificationChannel(channelId,
                    channelName, NotificationManager.IMPORTANCE_LOW));
        }
        if (getIntent().getExtras() != null) {
            for (String key : getIntent().getExtras().keySet()) {
                Object value = getIntent().getExtras().get(key);
                // Log.d(TAG, "Key: " + key + " Value: " + value);
            }
        }
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull com.google.android.gms.tasks.Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            //   Log.w(TAG, "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();

                        // Log and toast
                        String msg = getString(R.string.msg_token_fmt, token);
                        Log.d(TAG, msg);
                        // Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });
        FirebaseMessaging.getInstance().subscribeToTopic("weather")
                .addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull com.google.android.gms.tasks.Task<Void> task) {
                        String msg = getString(R.string.msg_subscribed);
                        if (!task.isSuccessful()) {
                            msg = getString(R.string.msg_subscribe_failed);
                        }
                        Log.d(TAG, msg);
                        // Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });

    }


    private MoPubView moPubView;
    public void bannermopub() {
        moPubView = (MoPubView) findViewById(R.id.adview);
        moPubView.setAdUnitId(BANNER_MOPUB);
        moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
    }

    @Override
    public void onUnityAdsReady(String s) {

    }

    @Override
    public void onUnityAdsStart(String s) {

    }

    @Override
    public void onUnityAdsFinish(String s, UnityAds.FinishState finishState) {

    }

    @Override
    public void onUnityAdsError(UnityAds.UnityAdsError unityAdsError, String s) {

    }


    private static class UnityAdsListener implements IUnityAdsListener {
        @Override
        public void onUnityAdsReady (String placementId) {
            // Implement functionality for an ad being ready to show.
        }

        @Override
        public void onUnityAdsStart (String placementId) {
            // Implement functionality for a user starting to watch an ad.
        }

        @Override
        public void onUnityAdsFinish (String placementId, UnityAds.FinishState finishState) {
            // Implement functionality for a user finishing an ad.
        }

        @Override
        public void onUnityAdsError (UnityAds.UnityAdsError error, String message) {
            // Implement functionality for a Unity Ads service error occurring.
        }
    }

    BannerView bottomBanner;
    RelativeLayout bottomBannerView;
    public  void bannerunity(){
        bottomBanner = new BannerView(MainActivity.this, Unity_BANNER, new UnityBannerSize(320, 50));
        //bottomBanner.setListener(bannerListener);
        bottomBannerView = findViewById(R.id.bottomBanner);
        bottomBannerView.addView(bottomBanner);
        bottomBanner.load();
    }
}

