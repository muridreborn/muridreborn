package com.aliendroid.wallpaperalien.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.wallpaperalien.config.Pengaturan;
import com.mopub.mobileads.MoPubInterstitial;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.ArrayList;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.activity.DetailWallCari;
import com.aliendroid.wallpaperalien.model.WallList;


import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninter;
import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninterFan;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.interval;
import static com.aliendroid.wallpaperalien.activity.SplahsActivity.counter;

public class CategoriWallAdapter extends RecyclerView.Adapter<CategoriWallAdapter.ViewHolder>{

    private MoPubInterstitial mInterstitial;


    private final int VIEW_ITEM = 1;
    private final int VIEW_PROG = 0;
    private final int VIEW_ADS = 2;
    public static String JUDUL, IKON, DES;
    private Context cnt;
    // we define a list from the WebList java class

    //private List<WebList> webLists;
    //private List<WebList>  mFilteredList;

    private ArrayList<WallList> webLists;
   public static ArrayList<WallList> mFilteredList;


    private Context context;

    public CategoriWallAdapter(ArrayList<WallList> webLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.webLists = webLists;
        this.mFilteredList = webLists;
        this.context = context;

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        // define the View objects

        public TextView html_url;
        public ImageView avatar_url;
        public RelativeLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            mInterstitial = new MoPubInterstitial((Activity) context, Pengaturan.INTER_MOPUB);
            mInterstitial.load();

            html_url = (TextView) itemView.findViewById(R.id.username);
            avatar_url = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (RelativeLayout) itemView.findViewById(R.id.linearLayout);
        }




    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.wall_list, parent, false);
            return new ViewHolder(v);

    }



    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {

        // this method will bind the data to the ViewHolder from whence it'll be shown to other Views
        if (holder instanceof ViewHolder) {
            final WallList webList = mFilteredList.get(position);
            ((ViewHolder)holder).html_url.setText(webList.getHtml_url());

            Picasso.get()
                    .load(webList.getAvatar_url())
                    .into( ((ViewHolder)holder).avatar_url);

            ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Intent intent = new Intent(context, DetailWallCari.class);
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                    //((CategoryActivity)context).finish();

                    if (counter>=interval){
                        if (PENGATURAN_IKLAN.equals("1")){
                            iklaninter();
                        } else if (PENGATURAN_IKLAN.equals("2")){
                            iklaninterFan();
                        }else if (PENGATURAN_IKLAN.equals("3")){
                            StartAppAd.showAd(context);
                        }else if (PENGATURAN_IKLAN.equals("4")){

                        }else if (PENGATURAN_IKLAN.equals("5")){
                            if (mInterstitial.isReady()) {
                                mInterstitial.show();
                                mInterstitial.load();
                            } else {
                                mInterstitial.load();
                            }
                        }
                        counter=0;
                    } else {
                        counter++;
                    }
                }
            });
        }


    }

    @Override

    //return the size of the listItems (developersList)

    public int getItemCount() {
        return mFilteredList.size();
    }

    @Override
    public int getItemViewType(int position) {

        return VIEW_ITEM;
    }
    //public void setFilter(ArrayList<WebList> filterList){
    //        webLists = new ArrayList<>();
    //        webLists.addAll(filterList);
    //        notifyDataSetChanged();
    //    }

    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = webLists;
                } else {

                    ArrayList<WallList> filteredList = new ArrayList<>();

                    for (WallList androidVersion : mFilteredList) {

                        if (androidVersion.getAvatar_url().toLowerCase().contains(charString) || androidVersion.getAvatar_url().toLowerCase().contains(charString) || androidVersion.getHtml_url().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<WallList>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


}
