package com.aliendroid.wallpaperalien.activity;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.wallpaperalien.BuildConfig;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.ads.AdSettings;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.config.Pengaturan;
import com.mopub.common.MoPub;
import com.mopub.common.SdkConfiguration;
import com.mopub.common.SdkInitializationListener;


import static com.aliendroid.wallpaperalien.config.Pengaturan.BANNER_MOPUB;
import static com.aliendroid.wallpaperalien.config.Pengaturan.DATA_ON_OFF;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.STARAPPID;
import static com.aliendroid.wallpaperalien.config.Pengaturan.TESTMODE_FAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.URL_DATA;
import static com.mopub.common.logging.MoPubLog.LogLevel.DEBUG;
import static com.mopub.common.logging.MoPubLog.LogLevel.INFO;

public class SplahsActivity extends AppCompatActivity {
    final SdkConfiguration.Builder configBuilder = new SdkConfiguration.Builder(BANNER_MOPUB);
    public static int counter =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AudienceNetworkInitializeHelper.initialize(this);
        AdSettings.setTestMode(TESTMODE_FAN);
        setContentView(R.layout.splash);

        if (DATA_ON_OFF.equals("1")) {
            if (checkConnectivity()) {
                loadUrlData();
            } else {
                nointernetp();
            }

        }

        if (BuildConfig.DEBUG) {
            configBuilder.withLogLevel(DEBUG);
        } else {
            configBuilder.withLogLevel(INFO);
        }
        MoPub.initializeSdk(this, configBuilder.build(), initSdkListener());

        new CountDownTimer(8000, 1000) {
            @Override
            public void onFinish() {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onTick(long millisUntilFinished) {

            }
        }.start();
    }



    private void loadUrlData() {

        final ProgressDialog progressDialog = new ProgressDialog(SplahsActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

                try {

                    JSONObject jsonObj = new JSONObject(response);

                    // Getting JSON Array node
                    JSONArray contacts = jsonObj.getJSONArray("Iklan");

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String status = c.getString("status");
                        String link = c.getString("link");
                        String interid = c.getString("interid");
                        String openid = c.getString("openads");
                        String nativeid = c.getString("nativeid");
                        int interval = c.getInt("interval");
                        String pengaturan_iklan = c.getString("pengaturan_iklan");
                        String fan_inter = c.getString("fan_inter");
                        String fan_banner_native = c.getString("fan_banner_native");
                        String startaap = c.getString("startaap");

                        String mopub_banner= c.getString("mopub_banner");
                        String mopub_inter = c.getString("mopub_inter");

                        String unityID= c.getString("unityID");
                        String unity_inter = c.getString("unity_inter");
                        String unity_banner = c.getString("unity_banner");

                        Pengaturan.unityGameID = unityID;
                        Pengaturan.Unity_INTER = unity_inter;
                        Pengaturan.Unity_BANNER = unity_banner;

                        BANNER_MOPUB=mopub_banner;
                        Pengaturan.INTER_MOPUB=mopub_inter;

                        Pengaturan.FAN_BANNER_NATIVE=fan_banner_native;
                        Pengaturan.FAN_INTER=fan_inter;
                        PENGATURAN_IKLAN=pengaturan_iklan;
                        Pengaturan.interval=interval;
                        Pengaturan.STATUS=status;
                        Pengaturan.LINK=link;
                        Pengaturan.OPEN_ADS=openid;

                        Pengaturan.INTER=interid;
                        Pengaturan.NATIV=nativeid;

                        STARAPPID=startaap;


                    }

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(SplahsActivity.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SplahsActivity.this);
        requestQueue.add(stringRequest);
    }

    private void nointernetp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(SplahsActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_network_check_24);
        builder.setTitle("Bad Connection");
        builder.setMessage("No internet access, please activate the internet to use the app!");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Close",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        builder.setNegativeButton("Reload",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){

                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    private boolean checkConnectivity() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private SdkInitializationListener initSdkListener() {
        return new SdkInitializationListener() {
            @Override
            public void onInitializationFinished() {
           /* MoPub SDK initialized.
           Check if you should show the consent dialog here, and make your ad requests. */
            }
        };
    }
}
