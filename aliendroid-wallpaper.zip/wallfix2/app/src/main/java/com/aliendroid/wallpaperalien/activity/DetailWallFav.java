package com.aliendroid.wallpaperalien.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.mopub.mobileads.MoPubView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.BuildConfig;
import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.adapter.FavAdapter;
import com.aliendroid.wallpaperalien.adapter.Wall2Adapter;
import com.aliendroid.wallpaperalien.adapter.SharedPreference;
import com.aliendroid.wallpaperalien.model.WallList;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

import static com.aliendroid.wallpaperalien.activity.SplahsActivity.counter;
import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninter;
import static com.aliendroid.wallpaperalien.adapter.Wall2Adapter.iklaninterFan;
import static com.aliendroid.wallpaperalien.config.Pengaturan.BANNER_MOPUB;
import static com.aliendroid.wallpaperalien.config.Pengaturan.FAN_BANNER_NATIVE;
import static com.aliendroid.wallpaperalien.config.Pengaturan.NATIV;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.adapter.FavAdapter.webLists;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_BANNER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.interval;

public class DetailWallFav extends AppCompatActivity  implements NativeAdListener {
    private Button button;
    private Button bshare, sethome, setlock;
    private LinearLayout menuFl;
    private FloatingActionButton bfloat;
    public ImageView avatar_url;
    private WebView webView = null;
    private String htmlData = null;
    private int position = 0;
    private int i=0;
    private ImageView kembali;
    SharedPreference sharedPreference;
    private AdView adView;
    private LinearLayout bannerLayout ;
    private InterstitialAd mInterstitialAd;
    private RelativeLayout iklannative;
    private NativeBannerAd nativeBannerAd;
    private NativeAdLayout nativeAdLayout;
    private LinearLayout adView2;
    private ImageView bnext, bprev, bdown;
    @Override
    protected void onCreate(Bundle saveInsBundleState) {
        super.onCreate(saveInsBundleState);
        setContentView(R.layout.activity_detail_wall);
        menuFl = findViewById(R.id.menuFl);
        sharedPreference = new SharedPreference();


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        bfloat = (FloatingActionButton) findViewById(R.id.bfloat);
        button = (Button) findViewById(R.id.imageView4);
        bshare = (Button) findViewById(R.id.setlockhome);
        kembali = (ImageView) findViewById(R.id.imageView2);

        sethome=findViewById(R.id.imagesethome);
        setlock=findViewById(R.id.imagesetlock);
        bfloat.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (i==0){
                    menuFl.setVisibility(View.VISIBLE);

                    i++;
                } else {
                    menuFl.setVisibility(View.GONE);

                    i=0;
                }
            }
        });


        iklannative = (RelativeLayout) findViewById(R.id.iklannative) ;
        RelativeLayout starappiklan=findViewById(R.id.mainLayout);
        if (PENGATURAN_IKLAN.equals("1")){
            iklannativeadmob();
            starappiklan.setVisibility(View.GONE);


        } else if (PENGATURAN_IKLAN.equals("2")){
            nativbanner();
            starappiklan.setVisibility(View.GONE);
        } else if (PENGATURAN_IKLAN.equals("3")){
            starappiklan.setVisibility(View.VISIBLE);
        } else if (PENGATURAN_IKLAN.equals("4")){
            bannerunity();
            starappiklan.setVisibility(View.GONE);
        }else if (PENGATURAN_IKLAN.equals("5")){
           bannermopub();
            starappiklan.setVisibility(View.GONE);
        }


        if (ContextCompat.checkSelfPermission(DetailWallFav.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //Permission was denied
            //Request for permission
            ActivityCompat.requestPermissions(DetailWallFav.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    123);
        }


        kembali.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {



                finish();

            }
        });

        setSupportActionBar(toolbar);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            position = extras.getInt("position");
        } else {
            if (saveInsBundleState != null) {
                position = saveInsBundleState.getInt("position");
            } else {
                position = 1;
            }
        }

        /*If a product exists in shared preferences then set heart_red drawable
         * and set a tag*/
        if (checkFavoriteItem(FavAdapter.webLists.get(position))) {
            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
            button.setTag("red");

        } else {

            button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));
            button.setTag("gray");
        }


        setlock.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();

                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_LOCK);
                    }
                    Toast.makeText(DetailWallFav.this, "Wallpaper set Lock Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallFav.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }



            }


        });


        bshare.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {


                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();


                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWallFav.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallFav.this, "Your Device Does Not Support Lock Screen Wallpapers", Toast.LENGTH_SHORT).show();
                }



            }


        });

        sethome.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                Bitmap bitmap=((BitmapDrawable)avatar_url.getDrawable()).getBitmap();


                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(DetailWallFav.this, "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(DetailWallFav.this,
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }


            }


        });


        TextView textView = (TextView)toolbar.findViewById(R.id.toolbarTextView);
        textView.setText(webLists.get(position).getHtml_url());

        //sharedPreference.addFavorite(products.add(pos));

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        avatar_url = (ImageView) findViewById(R.id.imageView3);
       // webView = (WebView) findViewById(R.id.web_view);
        Picasso.get()
                .load(webLists.get(position).getAvatar_url())
                .into(avatar_url);

        String mimeType = "text/html";
        String encoding = "utf-8";

        // Load html source code into webview to show the html content.
        //webView.loadDataWithBaseURL(null, htmlData, mimeType, encoding, null);

        bnext = findViewById(R.id.bnext);
        bprev = findViewById(R.id.bprev);
        bdown = findViewById(R.id.bdown);
        bprev.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                position--;


                position = (position + FavAdapter.webLists.size()) % FavAdapter.webLists.size();

                Picasso.get()
                        .load(FavAdapter.webLists.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(FavAdapter.webLists.get(position).getHtml_url());
                if (counter>=interval){
                    if (PENGATURAN_IKLAN.equals("1")){
                        iklaninter();
                    } else if (PENGATURAN_IKLAN.equals("2")){
                        iklaninterFan();
                    }else if (PENGATURAN_IKLAN.equals("3")){
                        StartAppAd.showAd(DetailWallFav.this);
                    }else if (PENGATURAN_IKLAN.equals("4")){
                        if (UnityAds.isReady (Unity_INTER)) {
                            UnityAds.show (DetailWallFav.this,Unity_INTER);
                        }

                    }
                    counter=0;
                } else {
                    counter++;
                }
            }
        });

        bdown.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Picasso.get()
                        .load(FavAdapter.webLists.get(position).getAvatar_url())
                        .into(avatar_url);
                avatar_url.buildDrawingCache();

                Bitmap bmp = avatar_url.getDrawingCache();

                File storageLoc = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES); //context.getExternalFilesDir(null);

                File file = new File(storageLoc, FavAdapter.webLists.get(position).getHtml_url() + ".jpg");

                try{
                    FileOutputStream fos = new FileOutputStream(file);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                    fos.close();

                    scanFile(DetailWallFav.this, Uri.fromFile(file));

                    Toast.makeText(DetailWallFav.this,
                            "Saved successfully " + FavAdapter.webLists.get(position).getHtml_url(), Toast.LENGTH_SHORT)
                            .show();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (counter>=interval){
                    if (PENGATURAN_IKLAN.equals("1")){
                        iklaninter();
                    } else if (PENGATURAN_IKLAN.equals("2")){
                        iklaninterFan();
                    }else if (PENGATURAN_IKLAN.equals("3")){
                        StartAppAd.showAd(DetailWallFav.this);
                    }else if (PENGATURAN_IKLAN.equals("4")){
                        if (UnityAds.isReady (Unity_INTER)) {
                            UnityAds.show (DetailWallFav.this,Unity_INTER);
                        }
                    }
                    counter=0;
                } else {
                    counter++;
                }


            }
        });


        bnext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                position++;
                position = position % FavAdapter.webLists.size();

                Picasso.get()
                        .load(FavAdapter.webLists.get(position).getAvatar_url())
                        .into(avatar_url);
                textView.setText(FavAdapter.webLists.get(position).getHtml_url());
                if (counter>=interval){
                    if (PENGATURAN_IKLAN.equals("1")){
                        iklaninter();
                    } else if (PENGATURAN_IKLAN.equals("2")){
                        iklaninterFan();
                    }else if (PENGATURAN_IKLAN.equals("3")){
                        StartAppAd.showAd(DetailWallFav.this);
                    }else if (PENGATURAN_IKLAN.equals("4")){
                        if (UnityAds.isReady (Unity_INTER)) {
                            UnityAds.show (DetailWallFav.this,Unity_INTER);
                        }
                    }
                    counter=0;
                } else {
                    counter++;
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                String tag = button.getTag().toString();
                if(tag.equalsIgnoreCase("gray"))
                {
                    sharedPreference.addFavorite(DetailWallFav.this, FavAdapter.webLists.get(position));
                    button.setTag("red");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
                }
                else
                {
                    sharedPreference.removeFavorite(DetailWallFav.this, FavAdapter.webLists.get(position));
                    button.setTag("gray");
                    button.setBackground(getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));

                }
        }
        });




    }

    public Bitmap takeScreenshot() {
        View rootView = getWindow().getDecorView().findViewById(android.R.id.content);
        rootView.setDrawingCacheEnabled(true);
        return rootView.getDrawingCache();
    }



    File imagePath;
    private void saveBitmap(Bitmap bitmap) {
        imagePath = new File(Environment.getExternalStorageDirectory() + "/scrnshot.png"); ////File imagePath
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(imagePath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
            Log.e("GREC", e.getMessage(), e);
        } catch (IOException e) {
            Log.e("GREC", e.getMessage(), e);
        }
    }

    private void shareIt() {
        Uri uri = Uri.fromFile(imagePath);
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("image/*");
        String shareBody = "Read Wall " + Wall2Adapter.webLists.get(position).getHtml_url() + " Download " +
                "on Playstore" + " https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID;
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "My Catch score");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        sharingIntent.putExtra(Intent.EXTRA_STREAM, uri);

        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    @Override
    public void onSaveInstanceState(Bundle saveInsBundleState) {
        super.onSaveInstanceState(saveInsBundleState);
        saveInsBundleState.putInt("position", position);

    }

    public boolean checkFavoriteItem(WallList checkProduct) {
        boolean check = false;
        List<WallList> favorites = sharedPreference.getFavorites(this);
        if (favorites != null) {
            for (WallList product : favorites) {
                if (product.equals(checkProduct)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }

    public void onBackPressed(){


        finish();
    }

    /*
        native FAN
         */
    private LinearLayout mAdView;
    private FrameLayout mAdChoicesContainer;
    private NativeAdLayout mNativeBannerAdContainer;
    private @Nullable
    NativeBannerAd mNativeBannerAd;
    private boolean isAdViewAdded;

    public void nativbanner(){
        LayoutInflater inflater = LayoutInflater.from(DetailWallFav.this);
        mNativeBannerAdContainer = findViewById(R.id.native_banner_ad_container);
        mAdView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_unit, mNativeBannerAdContainer, false);
        mAdChoicesContainer = mAdView.findViewById(R.id.ad_choices_container);
        mNativeBannerAd = new NativeBannerAd(DetailWallFav.this, FAN_BANNER_NATIVE);
        inflateAd(mNativeBannerAd, mAdView);
        mNativeBannerAd.loadAd( mNativeBannerAd
                .buildLoadAdConfig()
                .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
                .withAdListener(DetailWallFav.this)
                .build());

    }


    private void inflateAd (NativeBannerAd nativeBannerAd, View adView) {
        // Create native UI using the ad metadata.
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Setting the Text
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());

        // You can use the following to specify the clickable areas.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdCallToAction);

        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        ImageView nativeImageViewAdIconView = adView.findViewById(R.id.image_view_icon_view);

        nativeAdIconView.setVisibility(View.VISIBLE);
        nativeImageViewAdIconView.setVisibility(View.GONE);
        nativeBannerAd.registerViewForInteraction(
                mNativeBannerAdContainer, nativeAdIconView, clickableViews);
        sponsoredLabel.setText(R.string.sponsored);
    }

    @Override
    public void onError(Ad ad, AdError adError) {

    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (mNativeBannerAd == null || mNativeBannerAd != ad) {
            // Race condition, load() called again before last ad was displayed
            return;
        }
        if (!isAdViewAdded) {
            isAdViewAdded = true;
            mNativeBannerAdContainer.addView(mAdView);
        }
        // Unregister last ad
        mNativeBannerAd.unregisterView();

        if (!mNativeBannerAd.isAdLoaded() || mNativeBannerAd.isAdInvalidated()) {
            return;
        }
        AdOptionsView adOptionsView =
                new AdOptionsView(
                        this,
                        mNativeBannerAd,
                        mNativeBannerAdContainer,
                        AdOptionsView.Orientation.HORIZONTAL,
                        20);
        mAdChoicesContainer.removeAllViews();
        mAdChoicesContainer.addView(adOptionsView);

        inflateAd(mNativeBannerAd, mAdView);

    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    @Override
    public void onMediaDownloaded(Ad ad) {

    }


    private void iklannativeadmob() {
        AdLoader adLoader = new AdLoader.Builder(this,NATIV)
                .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        NativeTemplateStyle styles = new
                                NativeTemplateStyle.Builder().build();

                        TemplateView template = findViewById(R.id.my_template);
                        template.setStyles(styles);
                        template.setNativeAd(unifiedNativeAd);

                    }



                })

                .withAdListener(new AdListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        iklannative.setVisibility(View.GONE);
                        bfloat.setVisibility(View.VISIBLE);
                    }

                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onAdLoaded() {
                        iklannative.setVisibility(View.VISIBLE);
                        bfloat.setVisibility(View.VISIBLE);
                    }

                })
                .withNativeAdOptions(new NativeAdOptions.Builder()
                        // Methods in the NativeAdOptions.Builder class can be
                        // used here to specify individual options settings.
                        .build())
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }
    private static void scanFile(Context context, Uri imageUri){
        Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        scanIntent.setData(imageUri);
        context.sendBroadcast(scanIntent);

    }
    private MoPubView moPubView;
    public void bannermopub() {
        moPubView = (MoPubView) findViewById(R.id.adview);
        moPubView.setAdUnitId(BANNER_MOPUB);
        moPubView.loadAd(MoPubView.MoPubAdSize.HEIGHT_50);
    }

    BannerView bottomBanner;
    RelativeLayout bottomBannerView;
    public  void bannerunity(){
        bottomBanner = new BannerView(DetailWallFav.this, Unity_BANNER, new UnityBannerSize(320, 50));
        //bottomBanner.setListener(bannerListener);
        bottomBannerView = findViewById(R.id.bottomBanner);
        bottomBannerView.addView(bottomBanner);
        bottomBanner.load();
    }

}
