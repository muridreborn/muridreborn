package com.aliendroid.wallpaperalien.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;



import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeBannerAd;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;

import com.google.android.gms.ads.InterstitialAd;
import com.mopub.mobileads.MoPubInterstitial;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.aliendroid.wallpaperalien.R;
import com.aliendroid.wallpaperalien.config.Pengaturan;
import com.aliendroid.wallpaperalien.model.WallList;
import com.aliendroid.wallpaperalien.activity.DetailWall;
import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;


import static com.aliendroid.wallpaperalien.config.Pengaturan.FAN_BANNER_NATIVE;
import static com.aliendroid.wallpaperalien.config.Pengaturan.FAN_INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.NATIV;
import static com.aliendroid.wallpaperalien.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.wallpaperalien.config.Pengaturan.Unity_INTER;
import static com.aliendroid.wallpaperalien.config.Pengaturan.interval;
import static com.aliendroid.wallpaperalien.activity.SplahsActivity.counter;



public class Wall2Adapter extends RecyclerView.Adapter {
    SharedPreference sharedPreference;
    private final int VIEW_ITEM = 0;
    public static ArrayList<WallList> webLists;
    public static ArrayList<WallList> mFilteredList;
    public Context context;
    public static  String ulrgbr;
    private static com.facebook.ads.InterstitialAd interstitialAdfb;
    private static InterstitialAd mInterstitialAd;
    private MoPubInterstitial mInterstitial;
    public static Intent intent;

    public Wall2Adapter(ArrayList<WallList> webLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.webLists = webLists;
        this.mFilteredList = webLists;
        this.context = context;
        sharedPreference = new SharedPreference();

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        // define the View objects

        public TextView html_url;
        public ImageView avatar_url;
        public RelativeLayout linearLayout;
        public Button favoriteImg;

        public ViewHolder(View itemView) {
            super(itemView);

            mInterstitialAd = new InterstitialAd(context);
            mInterstitialAd.setAdUnitId(INTER);
            mInterstitialAd.loadAd(new AdRequest.Builder().build());


            interstitialAdfb = new com.facebook.ads.InterstitialAd(context, FAN_INTER);
            interstitialAdfb.loadAd();

            mInterstitial = new MoPubInterstitial((Activity) context, Pengaturan.INTER_MOPUB);
            mInterstitial.load();

            html_url = (TextView) itemView.findViewById(R.id.username);
            avatar_url = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (RelativeLayout) itemView.findViewById(R.id.linearLayout);
            favoriteImg = (Button) itemView.findViewById(R.id.imageView5);
        }

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.wall_list, parent, false);
            return new ViewHolder(v);

        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_progressbar, parent, false);
            return new ProgressViewHolder(v);
        }

    }
    private static class ProgressViewHolder extends RecyclerView.ViewHolder {
        private static ProgressBar progressBar;

        private ProgressViewHolder(View v) {
            super(v);
            progressBar = v.findViewById(R.id.progressBar);
        }
    }



    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder,  final int position) {

        switch(getItem(position).getViewType()){
            case 0:{
                // this method will bind the data to the ViewHolder from whence it'll be shown to other Views
                if (holder instanceof ViewHolder) {
                    final WallList webList = mFilteredList.get(position);



                    ((ViewHolder)holder).html_url.setText(webList.getHtml_url());

                    Picasso.get()
                            .load(webList.getAvatar_url())
                            .into( ((ViewHolder)holder).avatar_url);

                    ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            intent = new Intent(context, DetailWall.class);
                            intent.putExtra("position", position);
                            context.startActivity(intent);
                            //((MainActivity)context).finish();
//                    ((Activity)context).finish();

                            if (counter>=interval){
                                if (PENGATURAN_IKLAN.equals("1")){
                                    iklaninter();
                                } else if (PENGATURAN_IKLAN.equals("2")){
                                    iklaninterFan();
                                    interstitialAdfb.loadAd();
                                } else if (PENGATURAN_IKLAN.equals("3")){
                                    StartAppAd.showAd(context);
                                } else if (PENGATURAN_IKLAN.equals("4")){
                                    if (UnityAds.isReady (Unity_INTER)) {
                                        UnityAds.show ((Activity) context,Unity_INTER);
                                    }
                                }else if (PENGATURAN_IKLAN.equals("5")){
                                    if (mInterstitial.isReady()) {
                                        mInterstitial.show();
                                        mInterstitial.load();
                                    } else {
                                        mInterstitial.load();
                                    }
                                }
                                counter=0;
                            } else {
                                counter++;
                            }


                        }
                    });

                    if (checkFavoriteItem(Wall2Adapter.mFilteredList.get(position))) {
                        ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_black_24dp));
                        ((ViewHolder)holder).favoriteImg.setTag("red");

                    } else {

                        ((ViewHolder)holder).favoriteImg.setBackground(context.getResources().getDrawable(R.drawable.ic_favorite_border_black_24dp));
                        ((ViewHolder)holder).favoriteImg.setTag("gray");
                    }


                }
                break;
            }
        }




    }

    @Override

    //return the size of the listItems (developersList)

    public int getItemCount() {
        return mFilteredList.size();
    }


    public WallList getItem(int position) {
        return mFilteredList.get(position);
    }

    /*Checks whether a particular product exists in SharedPreferences*/
    public boolean checkFavoriteItem(WallList checkProduct) {
        boolean check = false;
        List<WallList> favorites = sharedPreference.getFavorites(context);
        if (favorites != null) {
            for (WallList product : favorites) {
                if (product.equals(checkProduct)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }

    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = webLists;
                } else {

                    ArrayList<WallList> filteredList = new ArrayList<>();

                    for (WallList androidVersion : mFilteredList) {

                        if (androidVersion.getAvatar_url().toLowerCase().contains(charString) || androidVersion.getAvatar_url().toLowerCase().contains(charString) || androidVersion.getHtml_url().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<WallList>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    public static void iklaninter(){
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } else {
            mInterstitialAd.loadAd(new AdRequest.Builder().build());


        }
    }

    public static void iklaninterFan(){

        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
            interstitialAdfb.loadAd();
        } else {
            interstitialAdfb.show();
            interstitialAdfb.loadAd();
        }
    }


}
