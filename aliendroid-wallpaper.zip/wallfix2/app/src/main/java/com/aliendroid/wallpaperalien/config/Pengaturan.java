package com.aliendroid.wallpaperalien.config;

public class Pengaturan {

    /*
    Pengaturan Iklan online dan offline
     */
    public static String DATA_ON_OFF ="1";

    /*
    JSON data Wallpaper, More App dan Iklan, silahkan uplaod di hosting
    Archire.org dll
     */
    public static final String URL_DATA = "http://hexa.web.id/sample/wallpaper_v2.json";

    /*
    PENGATURAN_IKLAN="1" = Admob
    PENGATURAN_IKLAN="2" = FAN
    PENGATURAN_IKLAN="3" = Startapp
    PENGATURAN_IKLAN="4" = Unity
    PENGATURAN_IKLAN="5" = Mopub
     */
    public static String PENGATURAN_IKLAN="4";

    /*
    ID Admob
    */

    public static String INTER = "ca-app-pub-3940256099942544/1033173712";
    public static String OPEN_ADS = "ca-app-pub-3940256099942544/1033173712";
    public static String NATIV = "ca-app-pub-3940256099942544/2247696110";

    /*
    Modul redirect App, Gunakan STATUS="1" jika aplikasi di suspend, maka aplikasi secara
    otimatis akan terkunci dan melakukan redirect/membuka link baru (app live)
    Gunakan STATUS="0" jika aplikasi masih live
     */
    public static String STATUS = "0";
    public static String LINK = "https://play.google.com/store/apps/details?id=com.ad.tesiqkepribadia&hl=en";

    /*
    Jarak munculnya iklan intertitial didalam list konten / dengan hitungan klik.
    Silahkan ubah sesuai kebutuhan jumlah intervalnya
    */
    public static int interval = 3;

    /*
      ID starapp
       */
    public static String STARAPPID="201669628";

    /*
    ID Facebook Audience Network
    */
    public static String FAN_INTER="612492376332507_612493222999089";
    public static String FAN_BANNER_NATIVE="612492376332507_612492762999135";
    /*
    ubah menjadi TESTMODE_FAN = false; jika aplikasi akan di publish untuk
    mengganti iklan test menjadi iklan pribadi
  */
    public static  boolean TESTMODE_FAN = true;

    /*
    ID Inmobi
    */
    public static String BANNER_MOPUB = "b195f8dd8ded45fe847ad89ed1d016da" ;
    public static String INTER_MOPUB = "24534e1901884e398f1253216226017e" ;


    public static  boolean TESTMODE_UNITY_ADS = true;
    public static String unityGameID = "3896203";
    public static String Unity_INTER = "video";
    public static String Unity_BANNER = "bannerid";


    public static String Privacy_police="file:///android_asset/privacy_policy.html";

}

